/**
 Future support for a Scheduler
 @class Scheduler
 @constructor
 @return {Object} instantiated Scheduler
 **/

function Scheduler() {
    this.self = this;
};

Scheduler.prototype = {
    constructor: Scheduler
}