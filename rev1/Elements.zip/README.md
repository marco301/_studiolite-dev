SignageStudio Web Lite
======================

The world's only enterprise level, open source, 100% FREE, Digital Signage platform
------------------------------------------------------------------------

 - Based on the poplar SignageStudio ( [MediaSignage]: http://www.DigitalSignage.com )
 - Driven using Soap API and includes Helper SDK
 - Connected to a private mediaSERVER or the public mediaCLOUD
 - 100% open source based on GNU V3 license
 - Built using jQuery Mobile and designed with responsive layout in mind
 - Contributors are welcome, fork and notify


Documentation
------------------------------------------------------------------------
- Home page: http://www.digitalsignage.com/_html/open_source_digital_signage.html
- SignageStudio Web Lite on-line documentation: http://www.digitalsignage.com/msdocs/
- Jalapeno SDK on-line documentation: http://www.digitalsignage.com/msdocs/classes/Jalapeno.html


License
------------------------------------------------------------------------
- The SignageStudio Web Lite and Jalapeno SDK are available under GPL V3 3 https://github.com/born2net/signagestudio_web-lite/blob/master/LICENSE


